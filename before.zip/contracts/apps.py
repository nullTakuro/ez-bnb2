from django.apps import AppConfig


class ContractsConfig(AppConfig):
    name = 'contracts'
