from django.db import models
from enum import Enum

# Fixed choices/static
# Fixed calendar type choices
class calendarType(Enum):



class calendar(models.Model):
    property = models.ForeignKey(property)
    date = models.DateTimeField()
    type = models.CharField(choices = [(code, code.value) for code in calendarType])
