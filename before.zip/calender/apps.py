from django.apps import AppConfig


class CalenderConfig(AppConfig):
    name = 'calender'
